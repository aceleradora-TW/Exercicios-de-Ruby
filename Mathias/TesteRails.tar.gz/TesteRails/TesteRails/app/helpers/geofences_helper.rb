module GeofencesHelper
end
