class Geofence < ActiveRecord::Base
end
